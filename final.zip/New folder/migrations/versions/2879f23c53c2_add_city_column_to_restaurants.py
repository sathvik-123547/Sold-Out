from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic
revision = '2879f23c53c2'
down_revision = '9938d08024ff'
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table('restaurant', schema=None) as batch_op:
        # Add the 'city' column with a default value
        batch_op.add_column(sa.Column('city', sa.String(length=50), nullable=False, server_default='Unknown'))
    # Remove the default value
    op.execute("UPDATE restaurant SET city = 'Unknown' WHERE city IS NULL")
    with op.batch_alter_table('restaurant', schema=None) as batch_op:
        batch_op.alter_column('city', server_default=None)


def downgrade():
    with op.batch_alter_table('restaurant', schema=None) as batch_op:
        batch_op.drop_column('city')
