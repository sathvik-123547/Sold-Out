from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv
import os
from flask_migrate import Migrate

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY")  # Replace with a strong, unique key

# Database Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///restaurant_app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
migrate = Migrate(app, db)
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False, unique=True)
    email = db.Column(db.String(120), nullable=False, unique=True)
    password = db.Column(db.String(120), nullable=False)
    verified = db.Column(db.Boolean, default=False)
    location = db.Column(db.String(120), nullable=True)  # New field for location


class Favorite(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    restaurant_name = db.Column(db.String(120), nullable=False)

class Restaurant(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    latitude = db.Column(db.Float, nullable=False)  # Latitude of the restaurant
    longitude = db.Column(db.Float, nullable=False)  # Longitude of the restaurant
    status = db.Column(db.String(50), nullable=False)

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, EmailField, SubmitField
from wtforms.validators import DataRequired, Email, Length, EqualTo

from wtforms import StringField, PasswordField, EmailField, SubmitField
from wtforms.validators import DataRequired, Email, Length, EqualTo

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=20)])
    email = EmailField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    location = StringField('Location (City/Zip)', validators=[DataRequired()])  # New location field
    submit = SubmitField('Register')


class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

# Routes
@app.route("/", methods=["GET"])
def home():
    return redirect(url_for("login"))

@app.route("/create_account", methods=["GET", "POST"])
def create_account():
    form = RegistrationForm()
    if form.validate_on_submit():
        existing_user = User.query.filter((User.username == form.username.data) | (User.email == form.email.data)).first()
        if existing_user:
            return "Username or email already exists!"
        
        new_user = User(
            username=form.username.data,
            email=form.email.data,
            password=form.password.data,
            location=form.location.data  # Save the location
        )
        db.session.add(new_user)
        db.session.commit()
        
        # Send verification email (if implemented)
        return "Account created successfully! Please check your email to verify your account."
    return render_template("create_account.html", form=form)


@app.route("/login", methods=["GET", "POST"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data, password=form.password.data).first()
        if user:
            if not user.verified:
                return "Account not verified. Please check your email."
            
            session.permanent = True
            session["username"] = user.username
            return redirect(url_for("homepage"))
        return "Invalid login. Please try again."
    return render_template("login.html", form=form)

@app.route("/verify_email/<int:user_id>", methods=["GET"])
def verify_email(user_id):
    user = User.query.get(user_id)
    if not user:
        return "Invalid verification link."

    if user.verified:
        return "Account already verified."

    user.verified = True
    db.session.commit()
    return "Account verified successfully! You can now log in."

@app.route("/homepage", methods=["GET"])
def homepage():
    username = session.get("username", "Guest")
    user = User.query.filter_by(username=username).first()
    location = user.location if user else "Unknown"
    return render_template("homepage.html", username=username, location=location)


@app.route("/favorites", methods=["GET", "POST"])
def favorites():
    if "username" not in session:
        return redirect(url_for("login"))

    # Example favorites logic
    favorite_restaurants = ["Joe's Diner", "Pasta Place", "Burger Bonanza"]
    if request.method == "POST":
        new_favorite = request.form.get("new_favorite")
        if new_favorite:
            favorite_restaurants.append(new_favorite)
    return render_template("favorites.html", favorites=favorite_restaurants)

@app.route("/seed", methods=["GET"])
def seed_data():
    if not Restaurant.query.first():  # Check if the table is empty
        restaurants = [
            Restaurant(name="Joe's Diner", status="Available"),
            Restaurant(name="Pasta Place", status="Sold Out"),
            Restaurant(name="Burger Bonanza", status="Available"),
            Restaurant(name="Sushi Spot", status="Available")
        ]
        db.session.bulk_save_objects(restaurants)
        db.session.commit()
        return "Database seeded successfully!"
    return "Database already seeded!"
@app.route('/seed_restaurants', methods=['GET'])
def seed_restaurants():
    if not Restaurant.query.first():
        restaurants = [
            Restaurant(name="Joe's Diner", latitude=37.7749, longitude=-122.4194, status="Available"),
            Restaurant(name="Pasta Place", latitude=37.7849, longitude=-122.4094, status="Sold Out"),
            Restaurant(name="Burger Bonanza", latitude=37.7649, longitude=-122.4294, status="Available"),
            Restaurant(name="Sushi Spot", latitude=37.7549, longitude=-122.4394, status="Available"),
        ]
        db.session.bulk_save_objects(restaurants)
        db.session.commit()
        return "Restaurants seeded successfully!"
    return "Restaurants already seeded!"

from flask import request, jsonify
from sqlalchemy.sql import func
@app.route('/location', methods=['GET'])
def location_page():
    return render_template('location.html')
from math import radians, sin, cos, sqrt, atan2
from flask import request, jsonify

# Haversine formula to calculate the distance between two points on Earth
def haversine(lat1, lon1, lat2, lon2):
    lat1 = radians(lat1)
    lon1 = radians(lon1)
    lat2 = radians(lat2)
    lon2 = radians(lon2)

    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))

    radius = 6371  # Earth radius in kilometers
    distance = radius * c
    return distance

@app.route('/location', methods=['POST'])
def location():
    try:
        data = request.json
        user_lat = data.get('latitude')
        user_lon = data.get('longitude')

        if user_lat is None or user_lon is None:
            return jsonify(success=False, message="Latitude or longitude is missing.")

        # Query all restaurants from the database
        nearby_restaurants = Restaurant.query.all()
        nearby_restaurants_list = []

        # Check distance from the user to each restaurant
        for restaurant in nearby_restaurants:
            # Calculate distance between restaurant and user
            distance = haversine(user_lat, user_lon, restaurant.latitude, restaurant.longitude)
            print(f"Restaurant: {restaurant.name}, Distance: {distance} km")  # Debugging line

            # Only consider restaurants within a 1 km radius (adjust this threshold as needed)
            if distance < 100:
                nearby_restaurants_list.append(restaurant.name)

        if not nearby_restaurants_list:
            return jsonify(success=False, message="No restaurants found nearby.")

        return jsonify(success=True, restaurants=nearby_restaurants_list)

    except Exception as e:
        return jsonify(success=False, message=str(e))


@app.route("/all_restaurants", methods=["GET", "POST"])
def all_restaurants():
    if "username" not in session:
        return redirect(url_for("login"))

    restaurants = Restaurant.query.all()

    if request.method == "POST":
        search = request.form.get("search")
        if search:
            restaurants = Restaurant.query.filter(Restaurant.name.contains(search)).all()

    return render_template("all_restaurants.html", restaurants=restaurants)


@app.route("/account", methods=["GET", "POST"])
def account():
    if "username" not in session:
        return redirect(url_for("login"))

    user = User.query.filter_by(username=session["username"]).first()
    if not user:
        return redirect(url_for("login"))

    if request.method == "POST":
        new_email = request.form.get("email")
        new_location = request.form.get("location")

        if new_email:
            user.email = new_email
        if new_location:
            user.location = new_location
        
        db.session.commit()
        return render_template("account.html", user=user, message="Profile updated successfully!")
    
    return render_template("account.html", user=user)


@app.errorhandler(404)
def not_found(error):
    return render_template("404.html"), 404

@app.errorhandler(500)
def server_error(error):
    return render_template("500.html"), 500

from flask_mail import Mail, Message

# Mail Configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'  # Use your email provider's SMTP server
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False
app.config['MAIL_USERNAME'] = os.getenv("MAIL_USERNAME")  # Replace with your email
app.config['MAIL_PASSWORD'] = os.getenv("MAIL_PASSWORD")    # Replace with your email password
mail = Mail(app)

from datetime import timedelta

# Set session timeout to 30 minutes
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=30)
@app.route('/logout', methods=['POST'])
def logout():
    session.pop('user_id', None)  # Remove the user's session
    return redirect(url_for('login'))  # Redirect to homepage or login page


if __name__ == "__main__":
    app.run(debug=True)
