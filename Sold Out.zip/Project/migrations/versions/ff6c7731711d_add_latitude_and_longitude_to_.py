"""Add latitude and longitude to Restaurant model

Revision ID: ff6c7731711d
Revises: 12bcb25d09ae
Create Date: 2025-01-06 11:19:47.432596

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ff6c7731711d'
down_revision = '12bcb25d09ae'
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table('restaurant', schema=None) as batch_op:
        batch_op.add_column(sa.Column('latitude', sa.Float(), nullable=False, server_default='10'))
        batch_op.add_column(sa.Column('longitude', sa.Float(), nullable=False, server_default='10'))


def downgrade():
    with op.batch_alter_table('restaurant', schema=None) as batch_op:
        batch_op.drop_column('longitude')
        batch_op.drop_column('latitude')

    # ### end Alembic commands ###
